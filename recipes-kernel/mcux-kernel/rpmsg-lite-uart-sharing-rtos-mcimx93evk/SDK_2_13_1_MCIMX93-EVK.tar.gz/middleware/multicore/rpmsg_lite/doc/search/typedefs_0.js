var searchData=
[
  ['rl_5fept_5frx_5fcb_5ft',['rl_ept_rx_cb_t',['../group__rpmsg__lite.html#ga40d0f39ccf0df3c73ac65bd18da02bfd',1,'rpmsg_lite.h']]],
  ['rpmsg_5fns_5fnew_5fept_5fcb',['rpmsg_ns_new_ept_cb',['../group__rpmsg__ns.html#gae5a8f145ddda4e1c572ee1053d6d2259',1,'rpmsg_ns.h']]],
  ['rpmsg_5fqueue_5fhandle',['rpmsg_queue_handle',['../group__rpmsg__queue.html#gaa6d197ceb3befc71d29f7b4a969d3d3e',1,'rpmsg_queue.h']]]
];
