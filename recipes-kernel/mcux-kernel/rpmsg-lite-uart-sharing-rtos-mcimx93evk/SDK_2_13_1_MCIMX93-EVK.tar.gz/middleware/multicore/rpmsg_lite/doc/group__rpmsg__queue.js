var group__rpmsg__queue =
[
    [ "rpmsg_queue_handle", "group__rpmsg__queue.html#gaa6d197ceb3befc71d29f7b4a969d3d3e", null ],
    [ "rpmsg_queue_rx_cb", "group__rpmsg__queue.html#gaeb7cba094390762f1131884b2c7e89ce", null ],
    [ "rpmsg_queue_create", "group__rpmsg__queue.html#gaf2b13335342ec06d8c264bbb6e27c88f", null ],
    [ "rpmsg_queue_destroy", "group__rpmsg__queue.html#ga480a59ddeeef5f54f84cd3977efcd1ec", null ],
    [ "rpmsg_queue_recv", "group__rpmsg__queue.html#gaaed084bf79a613f41f0e100250ba2a99", null ],
    [ "rpmsg_queue_recv_nocopy", "group__rpmsg__queue.html#ga5b6528593ab94d2377967a1cf2ec6180", null ],
    [ "rpmsg_queue_nocopy_free", "group__rpmsg__queue.html#ga1c3cff098b9464fa89788510bda231a3", null ],
    [ "rpmsg_queue_get_current_size", "group__rpmsg__queue.html#ga2d65626ac1279a50be5e1f86ed80acbf", null ]
];