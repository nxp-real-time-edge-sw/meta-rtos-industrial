var searchData=
[
  ['link_5fid',['link_id',['../group__rpmsg__lite.html#a5fe45ceaad9bb289e2efa45b0204be41',1,'rpmsg_lite_instance']]],
  ['link_5fstate',['link_state',['../group__rpmsg__lite.html#a69643b8c8c9dc78a671eee1397836e34',1,'rpmsg_lite_instance']]],
  ['lock',['lock',['../group__rpmsg__lite.html#ab4f1d8d26a8fed002f3e113cb988b1a8',1,'rpmsg_lite_instance']]]
];
