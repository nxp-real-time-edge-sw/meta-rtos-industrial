var group__config =
[
    [ "rpmsg_default_config.h", "rpmsg__default__config_8h.html", null ],
    [ "RL_MS_PER_INTERVAL", "group__config.html#gab1d9d807155917143be3785751c67f79", null ],
    [ "RL_ALLOW_CUSTOM_SHMEM_CONFIG", "group__config.html#gabcd6816af179a4381bb90c9b32d8acc7", null ],
    [ "RL_BUFFER_PAYLOAD_SIZE", "group__config.html#ga4e0599085aeaa1fc8824015826c1e56b", null ],
    [ "RL_BUFFER_COUNT", "group__config.html#gab9a566c2e720eaa10348e84d35f8dde9", null ],
    [ "RL_API_HAS_ZEROCOPY", "group__config.html#ga931a9f16ee1aa309020c74cfe2eabf1f", null ],
    [ "RL_USE_STATIC_API", "group__config.html#ga287167874db5209903c7e391013ab485", null ],
    [ "RL_CLEAR_USED_BUFFERS", "group__config.html#ga8a47e919e7dcb7ba81ad9f315cf14d8d", null ],
    [ "RL_USE_MCMGR_IPC_ISR_HANDLER", "group__config.html#ga1b30d0352059e95ffe6075ade6373c16", null ],
    [ "RL_USE_ENVIRONMENT_CONTEXT", "group__config.html#ga20ac412396689025a366af64b0b8d354", null ],
    [ "RL_DEBUG_CHECK_BUFFERS", "group__config.html#ga5c53a7ca40cc6bef546c7fa7c22fd1f6", null ],
    [ "RL_ALLOW_CONSUMED_BUFFERS_NOTIFICATION", "group__config.html#ga5997b4fbd7e8cf22b41b75573e91a243", null ],
    [ "RL_ASSERT", "group__config.html#ga1b73e9943f6d0786eee8e91020cdca29", null ]
];