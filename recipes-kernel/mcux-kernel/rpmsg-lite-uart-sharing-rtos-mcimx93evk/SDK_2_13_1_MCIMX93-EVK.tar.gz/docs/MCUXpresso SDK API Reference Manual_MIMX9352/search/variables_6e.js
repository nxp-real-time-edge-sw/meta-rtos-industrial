var searchData=
[
  ['nbytes',['nbytes',['../a00024.html#a71e19bdaa2d6ed8e95d4b25497a45149',1,'_lpi2c_master_edma_handle::nbytes()'],['../a00028.html#a6cb0ef8b643f0c8da471897277a79e11',1,'_lpspi_master_edma_handle::nbytes()'],['../a00028.html#ac4304fd510994667fcc72cf37ef1345a',1,'_lpspi_slave_edma_handle::nbytes()'],['../a00031.html#a7ffb3be259d932a6a9f7e86aed4cc790',1,'_lpuart_edma_handle::nbytes()'],['../a00038.html#a5ac5f640e7f592189cc65c21180ff5e1',1,'_qspi_edma_handle::nbytes()'],['../a00040.html#a061d53e53af802d59eca8bc3171297ce',1,'sai_edma_handle::nbytes()'],['../a00015.html#ada2a3af3cbf20ed38a3669c963d49f7d',1,'edma_tcd_t::NBYTES()']]],
  ['nextchanedgemode',['nextChanEdgeMode',['../a00046.html#a700c20e23231ba39cf5413dde606d5fb',1,'tpm_dual_edge_capture_param_t']]],
  ['notifytype',['notifyType',['../a00036.html#a2ca3b1a52e315e072a8ab48fcc1dd62a',1,'notifier_notification_block_t']]]
];
