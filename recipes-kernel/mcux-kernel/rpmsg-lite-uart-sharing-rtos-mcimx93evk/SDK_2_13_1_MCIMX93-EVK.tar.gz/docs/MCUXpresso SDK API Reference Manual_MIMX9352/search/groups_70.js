var searchData=
[
  ['pmc0_3a_20power_20management_20controller',['PMC0: Power Management Controller',['../a00037.html',1,'']]],
  ['port_3a_20port_20control_20and_20interrupts',['PORT: Port Control and Interrupts',['../a00168.html',1,'']]]
];
