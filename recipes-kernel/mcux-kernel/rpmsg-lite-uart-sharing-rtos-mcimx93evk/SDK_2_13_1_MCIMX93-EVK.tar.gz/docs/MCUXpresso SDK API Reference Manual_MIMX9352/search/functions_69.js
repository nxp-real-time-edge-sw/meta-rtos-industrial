var searchData=
[
  ['icache_5finvalidatebyrange',['ICACHE_InvalidateByRange',['../a00151.html#gab9e79fa88e11db521b74f5316de68676',1,'fsl_cache.h']]]
];
