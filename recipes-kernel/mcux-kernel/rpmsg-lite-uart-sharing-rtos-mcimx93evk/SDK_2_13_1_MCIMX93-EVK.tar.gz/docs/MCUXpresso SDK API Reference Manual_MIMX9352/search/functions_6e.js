var searchData=
[
  ['notifier_5fcreatehandle',['NOTIFIER_CreateHandle',['../a00036.html#gaa2dfe33b4724d9c1025acdde1b1b3c31',1,'fsl_notifier.h']]],
  ['notifier_5fgeterrorcallbackindex',['NOTIFIER_GetErrorCallbackIndex',['../a00036.html#ga9736632c3beca486ec3f8dab504b839c',1,'fsl_notifier.h']]],
  ['notifier_5fswitchconfig',['NOTIFIER_SwitchConfig',['../a00036.html#ga9ca08c8f6fa9a7bafa9ecbe08603cd97',1,'fsl_notifier.h']]]
];
