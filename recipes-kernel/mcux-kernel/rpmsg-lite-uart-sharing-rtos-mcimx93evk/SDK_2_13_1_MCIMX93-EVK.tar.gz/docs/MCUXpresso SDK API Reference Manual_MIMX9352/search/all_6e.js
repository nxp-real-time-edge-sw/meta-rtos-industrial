var searchData=
[
  ['nbytes',['nbytes',['../a00024.html#a71e19bdaa2d6ed8e95d4b25497a45149',1,'_lpi2c_master_edma_handle::nbytes()'],['../a00028.html#a6cb0ef8b643f0c8da471897277a79e11',1,'_lpspi_master_edma_handle::nbytes()'],['../a00028.html#ac4304fd510994667fcc72cf37ef1345a',1,'_lpspi_slave_edma_handle::nbytes()'],['../a00031.html#a7ffb3be259d932a6a9f7e86aed4cc790',1,'_lpuart_edma_handle::nbytes()'],['../a00038.html#a5ac5f640e7f592189cc65c21180ff5e1',1,'_qspi_edma_handle::nbytes()'],['../a00040.html#a061d53e53af802d59eca8bc3171297ce',1,'sai_edma_handle::nbytes()'],['../a00015.html#ada2a3af3cbf20ed38a3669c963d49f7d',1,'edma_tcd_t::NBYTES()']]],
  ['nextchanedgemode',['nextChanEdgeMode',['../a00046.html#a700c20e23231ba39cf5413dde606d5fb',1,'tpm_dual_edge_capture_param_t']]],
  ['notification_20framework',['Notification Framework',['../a00036.html',1,'']]],
  ['notifier_5fcallback_5fconfig_5ft',['notifier_callback_config_t',['../a00036.html#a00246',1,'']]],
  ['notifier_5fcallback_5ft',['notifier_callback_t',['../a00036.html#gafd1d8cc01c496de8b4cd3990ff85415c',1,'fsl_notifier.h']]],
  ['notifier_5fcallback_5ftype_5ft',['notifier_callback_type_t',['../a00036.html#gaad75237e3cea51f8315cf6577b35db91',1,'fsl_notifier.h']]],
  ['notifier_5fcreatehandle',['NOTIFIER_CreateHandle',['../a00036.html#gaa2dfe33b4724d9c1025acdde1b1b3c31',1,'fsl_notifier.h']]],
  ['notifier_5fgeterrorcallbackindex',['NOTIFIER_GetErrorCallbackIndex',['../a00036.html#ga9736632c3beca486ec3f8dab504b839c',1,'fsl_notifier.h']]],
  ['notifier_5fhandle_5ft',['notifier_handle_t',['../a00036.html#a00247',1,'']]],
  ['notifier_5fnotification_5fblock_5ft',['notifier_notification_block_t',['../a00036.html#a00248',1,'']]],
  ['notifier_5fnotification_5ftype_5ft',['notifier_notification_type_t',['../a00036.html#ga5ee4314c2a52ee0af61985e7163a1be9',1,'fsl_notifier.h']]],
  ['notifier_5fpolicy_5ft',['notifier_policy_t',['../a00036.html#ga62e961564dc31b8155d128a3f6566409',1,'fsl_notifier.h']]],
  ['notifier_5fswitchconfig',['NOTIFIER_SwitchConfig',['../a00036.html#ga9ca08c8f6fa9a7bafa9ecbe08603cd97',1,'fsl_notifier.h']]],
  ['notifier_5fuser_5fconfig_5ft',['notifier_user_config_t',['../a00036.html#gad0b6e919f3ff69992b36a2734a650ec7',1,'fsl_notifier.h']]],
  ['notifier_5fuser_5ffunction_5ft',['notifier_user_function_t',['../a00036.html#gacb6a6d6f99e6ddfbb96dae53382949b2',1,'fsl_notifier.h']]],
  ['notifytype',['notifyType',['../a00036.html#a2ca3b1a52e315e072a8ab48fcc1dd62a',1,'notifier_notification_block_t']]]
];
