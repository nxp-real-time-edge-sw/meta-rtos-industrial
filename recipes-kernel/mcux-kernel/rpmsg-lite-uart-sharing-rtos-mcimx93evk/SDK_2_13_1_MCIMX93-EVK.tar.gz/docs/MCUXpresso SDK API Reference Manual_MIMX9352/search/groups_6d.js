var searchData=
[
  ['msmc_3a_20multicore_20system_20mode_20controller',['MSMC: Multicore System Mode Controller',['../a00045.html',1,'']]],
  ['mu_3a_20messaging_20unit',['MU: Messaging Unit',['../a00167.html',1,'']]]
];
