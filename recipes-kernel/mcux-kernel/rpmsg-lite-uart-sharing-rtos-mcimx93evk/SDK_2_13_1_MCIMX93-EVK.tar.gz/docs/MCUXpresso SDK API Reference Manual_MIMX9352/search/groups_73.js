var searchData=
[
  ['sai_3a_20serial_20audio_20interface',['SAI: Serial Audio Interface',['../a00170.html',1,'']]],
  ['sai_20driver',['SAI Driver',['../a00039.html',1,'']]],
  ['sai_20edma_20driver',['SAI EDMA Driver',['../a00040.html',1,'']]],
  ['system_20clock_20generator_20_28scg_29',['System Clock Generator (SCG)',['../a00150.html',1,'']]],
  ['sema42_3a_20hardware_20semaphores_20driver',['SEMA42: Hardware Semaphores Driver',['../a00171.html',1,'']]],
  ['serial_5fport_5fswo',['Serial_port_swo',['../a00042.html',1,'']]],
  ['serial_5fport_5fuart',['Serial_port_uart',['../a00183.html',1,'']]],
  ['serial_20manager',['Serial Manager',['../a00041.html',1,'']]],
  ['sgtl5000',['Sgtl5000',['../a00043.html',1,'']]],
  ['sgtl5000_5fadapter',['Sgtl5000_adapter',['../a00181.html',1,'']]],
  ['shell',['Shell',['../a00044.html',1,'']]]
];
