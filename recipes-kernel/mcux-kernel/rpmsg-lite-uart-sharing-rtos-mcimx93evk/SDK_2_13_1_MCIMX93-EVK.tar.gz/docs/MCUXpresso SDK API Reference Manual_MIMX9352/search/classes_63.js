var searchData=
[
  ['clock_5froot_5fconfig_5ft',['clock_root_config_t',['../a00009.html',1,'']]],
  ['codec_5fcapability_5ft',['codec_capability_t',['../a00010.html#a00205',1,'']]],
  ['codec_5fconfig_5ft',['codec_config_t',['../a00010.html#a00206',1,'']]],
  ['codec_5fi2c_5fconfig_5ft',['codec_i2c_config_t',['../a00011.html#a00207',1,'']]],
  ['crc_5fconfig_5ft',['crc_config_t',['../a00012.html#a00208',1,'']]]
];
