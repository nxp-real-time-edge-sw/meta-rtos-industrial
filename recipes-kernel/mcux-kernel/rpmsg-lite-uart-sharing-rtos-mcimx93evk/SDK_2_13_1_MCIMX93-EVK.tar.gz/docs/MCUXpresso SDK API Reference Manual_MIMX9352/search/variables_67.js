var searchData=
[
  ['g_5flpspidummydata',['g_lpspiDummyData',['../a00027.html#ga95e4847cd333277614975d46280df9dd',1,'fsl_lpspi.h']]],
  ['g_5fserialhandle',['g_serialHandle',['../a00175.html#gaad3c4240a1364156a239471ccdb9aa0b',1,'fsl_debug_console.h']]]
];
