var searchData=
[
  ['edma_3a_20enhanced_20direct_20memory_20access_20_28edma_29_20controller_20driver',['eDMA: Enhanced Direct Memory Access (eDMA) Controller Driver',['../a00015.html',1,'']]],
  ['ewm_3a_20external_20watchdog_20monitor_20driver',['EWM: External Watchdog Monitor Driver',['../a00016.html',1,'']]]
];
