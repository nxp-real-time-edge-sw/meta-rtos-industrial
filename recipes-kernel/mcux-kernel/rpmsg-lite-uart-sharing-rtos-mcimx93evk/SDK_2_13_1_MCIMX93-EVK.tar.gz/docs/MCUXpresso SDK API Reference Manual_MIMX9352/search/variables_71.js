var searchData=
[
  ['queuedriver',['queueDriver',['../a00039.html#a18dfdb245cb737f8a66976b707d3d487',1,'_sai_handle::queueDriver()'],['../a00040.html#a969d922d9b8b82ac4fee2d9bb63b6a5a',1,'sai_edma_handle::queueDriver()']]],
  ['queueuser',['queueUser',['../a00039.html#a9bc00ccd6c986f28ca3cbd0c45469b59',1,'_sai_handle::queueUser()'],['../a00040.html#a13a45007eebf06db42ed42bb83ee3dbd',1,'sai_edma_handle::queueUser()']]]
];
