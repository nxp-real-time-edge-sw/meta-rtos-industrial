var searchData=
[
  ['edma_5fchannel_5fpreemption_5fconfig_5ft',['edma_channel_Preemption_config_t',['../a00015.html#a00215',1,'']]],
  ['edma_5fconfig_5ft',['edma_config_t',['../a00015.html#a00216',1,'']]],
  ['edma_5fhandle_5ft',['edma_handle_t',['../a00015.html#a00217',1,'']]],
  ['edma_5fminor_5foffset_5fconfig_5ft',['edma_minor_offset_config_t',['../a00015.html#a00218',1,'']]],
  ['edma_5ftcd_5ft',['edma_tcd_t',['../a00015.html#a00219',1,'']]],
  ['edma_5ftransfer_5fconfig_5ft',['edma_transfer_config_t',['../a00015.html#a00220',1,'']]],
  ['ewm_5fconfig_5ft',['ewm_config_t',['../a00016.html#a00221',1,'']]]
];
