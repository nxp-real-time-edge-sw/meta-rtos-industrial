var a00011 =
[
    [ "codec_i2c_config_t", "a00011.html#a00207", [
      [ "codecI2CInstance", "a00011.html#afc9ec0baf7efc35817e3ecf2c8a58337", null ],
      [ "codecI2CSourceClock", "a00011.html#a37cb8111dd268ac2496202faf07568b9", null ]
    ] ],
    [ "CODEC_I2C_MASTER_HANDLER_SIZE", "a00011.html#ga708be0fda3516367fe0461a5f054118c", null ],
    [ "codec_reg_addr_t", "a00011.html#ga0efd6653dc35bf1c3ac3516b8580c560", [
      [ "kCODEC_RegAddr8Bit", "a00011.html#gga0efd6653dc35bf1c3ac3516b8580c560a1ee21f0f2d15f0a1e3708aa041c67977", null ],
      [ "kCODEC_RegAddr16Bit", "a00011.html#gga0efd6653dc35bf1c3ac3516b8580c560a6bb003f6339c896cab91d395e515431d", null ]
    ] ],
    [ "codec_reg_width_t", "a00011.html#ga29f27d00fb6b1d4207c919daf85c99e4", [
      [ "kCODEC_RegWidth8Bit", "a00011.html#gga29f27d00fb6b1d4207c919daf85c99e4a6924318365a3be4d1f806bbf822f24a7", null ],
      [ "kCODEC_RegWidth16Bit", "a00011.html#gga29f27d00fb6b1d4207c919daf85c99e4adcf918639278d1d38a99f9b40030861a", null ],
      [ "kCODEC_RegWidth32Bit", "a00011.html#gga29f27d00fb6b1d4207c919daf85c99e4a1135b4284f4e9e0d83113250763b955f", null ]
    ] ],
    [ "CODEC_I2C_Init", "a00011.html#gadf64ef142b3bbc5a2f9ba1b7e01e5356", null ],
    [ "CODEC_I2C_Deinit", "a00011.html#ga2c33fdd5bd6fe377e53f92cbbb03223b", null ],
    [ "CODEC_I2C_Send", "a00011.html#gaadd85b986313b7ee984cd57bc9b883b4", null ],
    [ "CODEC_I2C_Receive", "a00011.html#gae0da3dcb4574fedde25b82432890e2ec", null ]
];