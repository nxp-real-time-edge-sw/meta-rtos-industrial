var a00179 =
[
    [ "HAL_CODEC_DA7212_HANDLER_SIZE", "a00179.html#ga173dfeeef7902d45872dda51415e491c", null ],
    [ "HAL_CODEC_DA7212_Init", "a00179.html#gad2878812173fd02ba209f366d37a037f", null ],
    [ "HAL_CODEC_DA7212_Deinit", "a00179.html#gab08612c5e25aebc93b1b0eac7a035d44", null ],
    [ "HAL_CODEC_DA7212_SetFormat", "a00179.html#ga9249dc767a2179dd2b666e3c59648318", null ],
    [ "HAL_CODEC_DA7212_SetVolume", "a00179.html#ga6269832c9c20f767210bd9a92f772bc5", null ],
    [ "HAL_CODEC_DA7212_SetMute", "a00179.html#gacc5832132f03f70a25ff8341b2eb4bd2", null ],
    [ "HAL_CODEC_DA7212_SetPower", "a00179.html#gad8d264496a300cde89479476a976b836", null ],
    [ "HAL_CODEC_DA7212_SetRecord", "a00179.html#gaf50862b15148b0253f69e8ba98ee79e9", null ],
    [ "HAL_CODEC_DA7212_SetRecordChannel", "a00179.html#ga1c26c8c2e37e902ceca4d7293a372f27", null ],
    [ "HAL_CODEC_DA7212_SetPlay", "a00179.html#ga6e685671791b6ba58bd1e2585e04d823", null ],
    [ "HAL_CODEC_DA7212_ModuleControl", "a00179.html#ga08647e657d0303daf67c64e7656bdac7", null ],
    [ "HAL_CODEC_Init", "a00179.html#gafe47075da9b829e30e618a86ac2cc9c6", null ],
    [ "HAL_CODEC_Deinit", "a00179.html#ga6728d97d2c909d8bff9fee477b0cd9e9", null ],
    [ "HAL_CODEC_SetFormat", "a00179.html#gaaf073d16e55b2da18b4b801acd03454b", null ],
    [ "HAL_CODEC_SetVolume", "a00179.html#ga17769c66cf7b5c0f01041e7f36f4c89c", null ],
    [ "HAL_CODEC_SetMute", "a00179.html#ga6e3171b042e6150ac410abced6123feb", null ],
    [ "HAL_CODEC_SetPower", "a00179.html#gad630677f451ca311d9f149d34da70637", null ],
    [ "HAL_CODEC_SetRecord", "a00179.html#ga78612feccab62150fb8ee1ef9eb4b6ed", null ],
    [ "HAL_CODEC_SetRecordChannel", "a00179.html#gad96c5638cbc67a85bfdb44aa1eee435b", null ],
    [ "HAL_CODEC_SetPlay", "a00179.html#ga10228c6005d118872915a0412c466a7d", null ],
    [ "HAL_CODEC_ModuleControl", "a00179.html#gab2e790a1ed09bc9a6b910d94180e5bd4", null ]
];